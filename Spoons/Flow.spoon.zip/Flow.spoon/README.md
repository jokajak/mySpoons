# Flow.spoon

This spoon supports workflows.

* All modes return to desktop mode when escape is pressed
* A class called ModalPkg provides the modal escape method
